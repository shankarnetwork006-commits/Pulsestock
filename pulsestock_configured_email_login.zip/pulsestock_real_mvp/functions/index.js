const {onCall,HttpsError}=require("firebase-functions/v2/https");
const {initializeApp}=require("firebase-admin/app");
const {getFirestore,FieldValue}=require("firebase-admin/firestore");
initializeApp();const db=getFirestore();
const allowed=new Set(["HDFCBANK","RELIANCE","TCS","INFY","ICICIBANK","TATAMOTORS"]);
function dayIndia(){return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kolkata",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date())}
function valid(data){if(!data||!allowed.has(data.ticker))throw new HttpsError("invalid-argument","Unsupported stock ticker");}
exports.recordVote=onCall({maxInstances:20,region:"asia-south1"},async req=>{
 if(!req.auth)throw new HttpsError("unauthenticated","Login required");valid(req.data);
 const {ticker,vote}=req.data;if(!["buy","sell","hold"].includes(vote))throw new HttpsError("invalid-argument","Invalid vote");
 const day=dayIndia(),voteRef=db.doc(`dailyVotes/${day}_${req.auth.uid}_${ticker}`),statRef=db.doc(`dailyStats/${day}_${ticker}`);
 await db.runTransaction(async tx=>{const old=await tx.get(voteRef),s=await tx.get(statRef),d=s.data()||{buy:0,sell:0,hold:0,views:0};if(old.data()?.vote===vote)return;if(old.exists)d[old.data().vote]=Math.max(0,(d[old.data().vote]||0)-1);d[vote]=(d[vote]||0)+1;tx.set(voteRef,{uid:req.auth.uid,ticker,vote,day,updatedAt:FieldValue.serverTimestamp()});tx.set(statRef,{...d,updatedAt:FieldValue.serverTimestamp()});});
 return {ok:true};
});
exports.recordView=onCall({maxInstances:20,region:"asia-south1"},async req=>{
 if(!req.auth)throw new HttpsError("unauthenticated","Login required");valid(req.data);
 const {ticker}=req.data,day=dayIndia(),viewRef=db.doc(`dailyViews/${day}_${req.auth.uid}_${ticker}`),statRef=db.doc(`dailyStats/${day}_${ticker}`);
 await db.runTransaction(async tx=>{const old=await tx.get(viewRef);if(old.exists)return;tx.create(viewRef,{uid:req.auth.uid,ticker,day,createdAt:FieldValue.serverTimestamp()});tx.set(statRef,{views:FieldValue.increment(1),updatedAt:FieldValue.serverTimestamp()},{merge:true});});
 return {ok:true};
});